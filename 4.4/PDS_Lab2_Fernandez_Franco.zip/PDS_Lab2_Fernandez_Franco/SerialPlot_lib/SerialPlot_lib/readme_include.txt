

Add the Library project as a dependency for your project in PSoC Creator. 
Go to Project > Dependencies > Add User Depencency